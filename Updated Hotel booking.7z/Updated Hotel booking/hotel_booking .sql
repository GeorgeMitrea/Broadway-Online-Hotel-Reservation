-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 24, 2017 at 03:07 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hotel_booking`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_room`
--

CREATE TABLE `add_room` (
  `room_id` int(11) NOT NULL,
  `room_number` varchar(50) NOT NULL,
  `room_type` varchar(50) NOT NULL,
  `room_price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `add_room`
--

INSERT INTO `add_room` (`room_id`, `room_number`, `room_type`, `room_price`) VALUES
(1, '111', 'double en-suite', 45);

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact_number` int(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `message` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`name`, `email`, `contact_number`, `address`, `message`) VALUES
('sabra', 'sabra@gmail.com', 678885685, 'uk', 'good services');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `contact_number` int(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `name`, `dob`, `contact_number`, `address`, `password`) VALUES
(3, 'sabra', '12-12-1900', 6789876, 'London', 'sabra'),
(4, 'harry', '12-09-1889', 3345555, 'Canada', 'harry'),
(5, 'pooja', '15-03-1996', 9676876, 'US', '123');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `number` int(50) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`id`, `name`, `email`, `number`, `role`) VALUES
(2, 'Thomas', 'Thomas@gmail.com', 3545733, 'manager'),
(4, 'Liam', 'Liam', 45654374, 'CEO');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `Role` varchar(50) NOT NULL,
  `contact_number` int(50) NOT NULL,
  `email id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `password`, `Role`, `contact_number`, `email id`) VALUES
(1, 'admin', '123', 'admin', 325345, 'admin@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `id` int(50) NOT NULL,
  `room_type` varchar(50) NOT NULL,
  `room` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `arrival` varchar(50) NOT NULL,
  `departure` varchar(50) NOT NULL,
  `guest` int(10) NOT NULL,
  `Total_price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`id`, `room_type`, `room`, `name`, `arrival`, `departure`, `guest`, `Total_price`) VALUES
(3, 'double en-suite', 103, 'devil', '12/25/2017', '12/27/2017', 1, 69.95),
(6, 'twin', 103, 'paridhi', '12/12/2017', '12/20/2017', 2, 0),
(7, 'twin', 102, 'john', '12/21/2017', '12/22/2017', 2, 0),
(8, 'twin', 104, 'alina', '12/26/2017', '12/27/2017', 2, 0),
(10, 'double en-suite', 101, 'hj', '12/06/2017', '12/12/2017', 2, 0),
(11, 'twin', 102, 'jbhfgb', '12/21/2017', '12/26/2017', 1, 0),
(12, 'twin', 102, 'jj', '12/05/2017', '12/29/2017', 2, 64.95);

-- --------------------------------------------------------

--
-- Table structure for table `room_facility`
--

CREATE TABLE `room_facility` (
  `id` int(50) NOT NULL,
  `room_type` varchar(50) NOT NULL,
  `room_number` int(50) NOT NULL,
  `food` varchar(50) NOT NULL,
  `mini_bar` varchar(50) NOT NULL,
  `AC` varchar(20) NOT NULL,
  `WIFI` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room_facility`
--

INSERT INTO `room_facility` (`id`, `room_type`, `room_number`, `food`, `mini_bar`, `AC`, `WIFI`) VALUES
(2, 'double en-suite', 111, 'Yes', 'Yes', 'Yes', 'Yes'),
(6, 'Twin', 105, 'Yes', 'No ', 'No ', 'No '),
(7, 'double en-suite', 113, 'No ', 'No ', 'Yes', 'Yes'),
(8, 'double en-suite', 113, 'Yes', 'Yes', 'Yes', 'Yes'),
(9, 'double en-suite', 113, 'Yes', 'Yes', 'Yes', 'No ');

-- --------------------------------------------------------

--
-- Table structure for table `room_type`
--

CREATE TABLE `room_type` (
  `room_id` int(50) NOT NULL,
  `room_type` varchar(50) NOT NULL,
  `price` double NOT NULL,
  `supplement` double NOT NULL,
  `Room_available` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `room_type`
--

INSERT INTO `room_type` (`room_id`, `room_type`, `price`, `supplement`, `Room_available`) VALUES
(1, 'twin', 34, 12, '101-107');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_room`
--
ALTER TABLE `add_room`
  ADD PRIMARY KEY (`room_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room_facility`
--
ALTER TABLE `room_facility`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `room_type`
--
ALTER TABLE `room_type`
  ADD PRIMARY KEY (`room_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_room`
--
ALTER TABLE `add_room`
  MODIFY `room_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `room_facility`
--
ALTER TABLE `room_facility`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `room_type`
--
ALTER TABLE `room_type`
  MODIFY `room_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
