
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Admin extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        try (PrintWriter out = response.getWriter()) {
            String id = request.getParameter("admin_id");
            String name = request.getParameter("admin_name");
            String pass = request.getParameter("admin_pass");
            String role = request.getParameter("admin_role");
            String number = request.getParameter("admin_number");
            String email = request.getParameter("admin_email");
            MyDb db = new MyDb();
            Connection con = db.getCon();
            Statement stmt = con.createStatement();

            String admin = "";
            String sqlbalance1 = ("SELECT `login`.`name` FROM `login`WHERE `login`.`id` = '" + id + "'");
            ResultSet admin_id = stmt.executeQuery(sqlbalance1);
            while (admin_id.next()) {
                admin = admin_id.getString("name");

            }

            if (admin.equals(name)) {

                String sql2 = ("UPDATE `login` SET `name` = '" + name + "' WHERE `login`.`id` = '" + id + "'");
                String sql3 = ("UPDATE `login` SET `password` = '" + pass + "' WHERE `login`.`id` = '" + id + "'");
                String sql4 = ("UPDATE `login` SET `Role` = '" + role + "' WHERE `login`.`id` = '" + id + "'");
                String sql5 = ("UPDATE `login` SET `contact_number` = '" + number + "' WHERE `login`.`id` = '" + id + "'");
                String sql6 = ("UPDATE `login` SET `email id` = '" + email + "' WHERE `login`.`id` = '" + id + "'");
                stmt.executeUpdate(sql2);
                stmt.executeUpdate(sql3);
                stmt.executeUpdate(sql4);
                stmt.executeUpdate(sql5);
                stmt.executeUpdate(sql6);

                response.sendRedirect("success_admin_edit.html");

            } else {
                response.sendRedirect("error_edit_admin.html");
            }

        } catch (Exception e) {
            System.out.println("invalid input");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
