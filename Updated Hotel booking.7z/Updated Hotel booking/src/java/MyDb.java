
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


public class MyDb {
    
    
     Connection con;
     public  Connection getCon()
     {
              try{                              
                Class.forName("com.mysql.jdbc.Driver");
               // dbConn = DriverManager.getConnection(db_URL, dbUSER, dbPASS);
                 con = DriverManager.getConnection("jdbc:mysql://localhost:3306/hotel_booking?zeroDateTimeBehavior=convertToNull", "root", "");
              }
              catch(Exception e)
              {
                   System.out.println("not connection");
              }
                
                
               
     return con;
     }
    
}
