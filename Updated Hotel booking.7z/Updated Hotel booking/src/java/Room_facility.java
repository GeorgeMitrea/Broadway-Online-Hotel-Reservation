/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Room_facility extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

           
            String edit_room_type = request.getParameter("edit_room_type");
            String edit_food_facility = request.getParameter("edit_food_facility");
            String edit_Mini_bar_facility = request.getParameter("edit_Mini_bar_facility");
            String edit_AC_facility = request.getParameter("edit_AC_facility");
            String edit_WIFI_facility = request.getParameter("edit_WIFI_facility");

            String edit_room_id = request.getParameter("edit_room_id");
            String edit_room_number = request.getParameter("edit_room_number");
            MyDb db = new MyDb();
            Connection con = db.getCon();
            Statement stmt = con.createStatement();

           
           /* try {
                String delete_facility = ("DELETE  FROM `room_facility` WHERE `room_facility`.`room_number` = '" + dlt_facility + "'");
                stmt.execute(delete_facility);
            } catch (Exception e3) {

            }*/

            String facility = "";
            try {
                String sql = ("SELECT `room_facility`.`room_number` FROM `room_facility` WHERE `room_facility`.`id` = '" + edit_room_id + "'");
                ResultSet sql_id = stmt.executeQuery(sql);
                while (sql_id.next()) {
                    facility = sql_id.getString("room_number");

                }

                if (facility.equals(edit_room_number)) {

                    String sql2 = ("UPDATE `room_facility` SET `room_type` = '" + edit_room_type + "' WHERE `room_facility`.`id` = '" + edit_room_id + "'");

                    String sql4 = ("UPDATE `room_facility` SET `food` = '" + edit_food_facility + "' WHERE `room_facility`.`id` = '" + edit_room_id + "'");
                    String sql5 = ("UPDATE `room_facility` SET `mini_bar` = '" + edit_Mini_bar_facility + "' WHERE `room_facility`.`id` = '" + edit_room_id + "'");
                    String sql6 = ("UPDATE `room_facility` SET `AC` = '" + edit_AC_facility + "' WHERE `room_facility`.`id` = '" + edit_room_id + "'");
                    String sql7 = ("UPDATE `room_facility` SET `WIFI` = '" + edit_WIFI_facility + "' WHERE `room_facility`.`id` = '" + edit_room_id + "'");

                    stmt.executeUpdate(sql2);
                    stmt.executeUpdate(sql4);
                    stmt.executeUpdate(sql5);
                    stmt.executeUpdate(sql6);
                    stmt.executeUpdate(sql7);

                    response.sendRedirect("successfull roomfacility_edited.html");

                } else {
                    response.sendRedirect("error_room_delete.html");
                }

            } catch (Exception e3) {

            }

        } catch (Exception e) {

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
