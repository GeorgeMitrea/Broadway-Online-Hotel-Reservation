
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class addroomfacility extends HttpServlet {

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
          
            
            String room_type = request.getParameter("room_type");
            String room_number = request.getParameter("room_number");
            String Mini_bar_facility = request.getParameter("Mini_bar_facility");
            String food_facility = request.getParameter("food_facility");
            String AC_facility = request.getParameter("AC_facility");
            String WIFI_facility = request.getParameter("WIFI_facility");
            //String dlt_facility = request.getParameter("dlt_facility");
            
              MyDb db = new MyDb();
            Connection con = db.getCon();
            Statement stmt = con.createStatement();
             try {
                String fac = ("INSERT INTO `room_facility` (`room_type`, `room_number`,`food`, `mini_bar`, `AC`, `WIFI`) VALUES ('" + room_type + "', '" + room_number + "', '" + food_facility + "', '" + Mini_bar_facility + "', '" + AC_facility + "', '" + WIFI_facility + "')");
                stmt.executeUpdate(fac);
                response.sendRedirect("successful roomfacilityadded.html");
            } catch (Exception e2) {

            }
            
            
        }
        catch(Exception e)
        {
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
