/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class edit_room_type extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
           
              String edit_room_type = request.getParameter("edit_room_type");
            String edit_price = request.getParameter("edit_price");
            String edit_supplement = request.getParameter("edit_supplement");
            String edit_Room_available = request.getParameter("edit_Room_available");

            String edit_room_typeid = request.getParameter("edit_room_typeid");
             MyDb db = new MyDb();
            Connection con = db.getCon();
            Statement stmt = con.createStatement();
            String roomtype = "";
            try {
                String sqltype = ("SELECT `room_type`.`room_type` FROM `room_type` WHERE `room_type`.`room_id` = '" + edit_room_typeid + "'");
                ResultSet sql_type = stmt.executeQuery(sqltype);
                while (sql_type.next()) {
                    roomtype = sql_type.getString("room_type");

                }
                

                if (roomtype.equals(edit_room_type)) {

                    String sql2 = ("UPDATE `room_type` SET `room_id` = '" + edit_room_type + "' WHERE `employee`.`room_id` = '" + edit_room_typeid+ "'");
                    String sql3 = ("UPDATE `room_type` SET `price` = '" + edit_price + "' WHERE `room_type`.`room_id` = '" + edit_room_typeid + "'");
                    String sql4 = ("UPDATE `room_type` SET `supplement` = '" + edit_supplement + "' WHERE `room_type`.`room_id` = '" + edit_room_typeid + "'");
                    String sql5 = ("UPDATE `room_type` SET `Room_available` = '" + edit_Room_available + "' WHERE `room_type`.`room_id` = '" + edit_room_typeid + "'");

                    // stmt.executeUpdate(sql2);
                    stmt.executeUpdate(sql3);
                    stmt.executeUpdate(sql4);
                    stmt.executeUpdate(sql5);
                    response.sendRedirect("successfully room_type_edited.html");

                } else {
                    response.sendRedirect("error_roomtype.html");
                }

            } catch (Exception e3) {

            }
            
           
            
            
            
            
        }
        
        catch(Exception e)
        {
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
