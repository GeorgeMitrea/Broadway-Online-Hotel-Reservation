

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class editroom extends HttpServlet {

   
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
          String edit_room_id = request.getParameter("edit_room_id");
            String edit_room_number = request.getParameter("edit_room_number");
            String edit_room_type = request.getParameter("edit_room_type");
            String edit_room_price = request.getParameter("edit_room_price");
            MyDb db = new MyDb();
            Connection con = db.getCon();
            Statement stmt = con.createStatement();
             String roomNumber = "";
            try {
                String sqlbalance1 = ("SELECT `add_room`.`room_number` FROM `add_room` WHERE `add_room`.`room_id` = '" + edit_room_id + "'");
                ResultSet sql_id = stmt.executeQuery(sqlbalance1);
                while (sql_id.next()) {
                    roomNumber = sql_id.getString("room_number");

                }

                if (roomNumber.equals(edit_room_number)) {

                    String sql2 = ("UPDATE `add_room` SET `room_number` = '" + edit_room_number + "' WHERE `add_room`.`room_id` = '" + edit_room_id + "'");
                    String sql3 = ("UPDATE `add_room` SET `room_price` = '" + edit_room_price + "' WHERE `add_room`.`room_id` = '" + edit_room_id + "'");
                    String sql4 = ("UPDATE `add_room` SET `room_type` = '" + edit_room_type + "' WHERE `add_room`.`room_id` = '" + edit_room_id + "'");

                    //stmt.executeUpdate(sql2);
                    stmt.executeUpdate(sql3);
                    stmt.executeUpdate(sql4);
                    response.sendRedirect("successfully roomedited.html");

                } else {
                     response.sendRedirect("error_room_delete.html");
                }

            } catch (Exception e3) {

            }
            
        }
        catch(Exception e)
        {
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
