
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*; // import libraries for Sql connectivity
import java.util.*;
import javax.swing.JOptionPane;

public class login extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
        String uname=request.getParameter("uname");
        String pass= request.getParameter("password");
        MyDb db=new MyDb();
        Connection con=  db.getCon();
         Statement stmt= con.createStatement();
         String user_name="";
         String sqlage = ("SELECT `login`.`name` FROM `login`");
                                ResultSet name= stmt.executeQuery(sqlage);
                                while (name.next()) {
                                    user_name =name.getString("name");

                                }
                                 String user_pass="";
          String sqlage1 = ("SELECT `login`.`password` FROM `login`");
                                ResultSet upass= stmt.executeQuery(sqlage1);
                                while (upass.next()) {
                                    user_pass =upass.getString("password");

                                }                      
       // String sql1= ("INSERT INTO `login` (`name`, `password`) VALUES ('" + uname + "', '" + pass+ "')");
        // int i =stmt.executeUpdate(sql1);
         if(uname.equals(user_name) &&pass.equals(user_pass)){  
                        response.sendRedirect("admin.html");                   
                        //stmt.close();
                    }
                    else {  
                      
                             response.sendRedirect("loginerror.html");   
                    } 
        }
        catch(Exception e1)
        {
            System.out.println("Connection not found");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
