
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class room extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            String room = request.getParameter("room");
            String name = request.getParameter("name");
            String arrival = request.getParameter("arrival");
            String departure = request.getParameter("departure");
            String total = request.getParameter("total");
            
            String double_room11 = request.getParameter("double_room");
            String double_name = request.getParameter("double_name");
            String double_arrival = request.getParameter("double_arrival");
            String double_departure = request.getParameter("double_departure");
            String double_total = request.getParameter("double_total");
            String twin_id = request.getParameter("twin_id");
           
            String edit_twinroom = request.getParameter("edit_twinroom");
            String edit_twinname = request.getParameter("edit_twinname");
            String edit_twinarrival = request.getParameter("edit_twinarrival");
            String edit_twindeparture = request.getParameter("edit_twindeparture");
            String edit_twintotal = request.getParameter("edit_twintotal");
            String doubleensuite_id = request.getParameter("doubleensuite_id");
            String edit_double_room = request.getParameter("edit_double_room");
            String edit_double_name = request.getParameter("edit_double_name");
            String edit_double_arrival = request.getParameter("edit_double_arrival");
            String edit_double_departure = request.getParameter("edit_double_departure");
            String edit_double_total = request.getParameter("edit_double_total");
            String dlt_name = request.getParameter("dlt_name");

            String Roomtype = "twin";
            String Roomtype1 = "double en-suite";
            MyDb db = new MyDb();
            Connection con = db.getCon();
            Statement stmt = con.createStatement();
            try {
                float people= Float.parseFloat(total); 
                double price= (44.95 +(10.00*people));
                String sql1 = ("INSERT INTO `room` (`room_type`,`room`, `name`,`arrival`, `departure`,`guest`,`Total_price`) VALUES ('" + Roomtype + "','" + room + "', '" + name + "', '" + arrival + "', '" + departure + "', '" + total + "','" + price + "')");
                stmt.executeUpdate(sql1);
                response.sendRedirect("successfull booking.html"); 

            } catch (Exception e) {
                System.out.println("invalid entries");
            }
            try {
                 float people= Float.parseFloat(double_total); 
                double price1= 54.95  +(15.00*people);
                String sql2 = ("INSERT INTO `room` (`room_type`,`room`, `name`,`arrival`, `departure`,`guest`,`Total_price`) VALUES ('" + Roomtype1 + "','" + double_room11 + "', '" + double_name + "', '" + double_arrival + "', '" + double_departure + "', '" + double_total + "','" + price1 + "')");
                 stmt.executeUpdate(sql2);
                 response.sendRedirect("successfull booking.html"); 
            } catch (Exception e) {
                System.out.println("invalid entries");
            }

            String cus_name = "";
            try {
                String sqlselect = ("SELECT `room`.`name` FROM `room` WHERE `room`.`id` = '" + twin_id + "'");
                ResultSet sql_room = stmt.executeQuery(sqlselect);
                while (sql_room.next()) {
                    cus_name = sql_room.getString("name");

                }

                if (cus_name.equals(edit_twinname)) {
                   float people= Float.parseFloat(edit_twintotal); 
                   
                double price= (44.95 +(10.00*people));
                    String sql2 = ("UPDATE `room` SET `room` = '" + edit_twinroom + "' WHERE `room`.`id` = '" + twin_id + "'");
                    String sql3 = ("UPDATE `room` SET `arrival` = '" + edit_twinarrival + "' WHERE `room`.`id` = '" + twin_id + "'");

                    String sql5 = ("UPDATE `room` SET `departure` = '" + edit_twindeparture + "' WHERE `room`.`id` = '" + twin_id + "'");
                    String sql4 = ("UPDATE `room` SET `guest` = '" + edit_twintotal + "' WHERE `room`.`id` = '" + twin_id + "'");
                     String sql6 = ("UPDATE `room` SET `Total_price` = '" + price + "' WHERE `room`.`id` = '" + twin_id + "'");
                    stmt.executeUpdate(sql2);
                    stmt.executeUpdate(sql3);
                    stmt.executeUpdate(sql5);
                    stmt.executeUpdate(sql4);
                      stmt.executeUpdate(sql6);
                   response.sendRedirect("successfully edited.html"); 
                } else {
                    response.sendRedirect("error_room_delete.html"); 
                }

            } catch (Exception e3) {

            }

            String cus_name1 = "";
            try {
                String sqlselect1 = ("SELECT `room`.`name` FROM `room` WHERE `room`.`id` = '" + doubleensuite_id + "'");
                ResultSet sql_room1 = stmt.executeQuery(sqlselect1);
                while (sql_room1.next()) {
                    cus_name1 = sql_room1.getString("name");

                }

                if (cus_name1.equals(edit_double_name)) {
                float people= Float.parseFloat(edit_double_total); 
                double price= 54.95  +(15.00*people);
                    String sql6 = ("UPDATE `room` SET `room` = '" + edit_double_room + "'  WHERE `room`.`id` = '" + doubleensuite_id + "'");
                    String sql7 = ("UPDATE `room` SET `arrival` = '" + edit_double_arrival + "' WHERE `room`.`id` = '" + doubleensuite_id + "'");

                    String sql8 = ("UPDATE `room` SET `departure` = '" + edit_double_departure + "' WHERE `room`.`id` = '" + doubleensuite_id + "'");
                    String sql9 = ("UPDATE `room` SET `guest` = '" + edit_double_total + "' WHERE `room`.`id` = '" + doubleensuite_id + "'");
                    String sql10 = ("UPDATE `room` SET `Total_price` = '" + price + "' WHERE `room`.`id` = '" + doubleensuite_id+ "'");
                    stmt.executeUpdate(sql6);
                    stmt.executeUpdate(sql7);
                    stmt.executeUpdate(sql8);
                    stmt.executeUpdate(sql9);
                   stmt.executeUpdate(sql10);
                   response.sendRedirect("successfully edited.html");
                } else {
                   response.sendRedirect("error_room_delete.html"); 
                }

            } catch (Exception e3) {

            }

            try {
                String delete_room = ("DELETE  FROM `room` WHERE `room`.`name` = '" + dlt_name + "'");
                stmt.execute(delete_room);
                 response.sendRedirect("successfully deleted.html"); 
                

            } catch (Exception e3) {

             response.sendRedirect("error_room_delete.html"); 
            }

        } catch (Exception e1) {
            System.out.println("connection not found");
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
